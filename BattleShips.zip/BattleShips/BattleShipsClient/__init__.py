name = 'BattleShipsClient'
