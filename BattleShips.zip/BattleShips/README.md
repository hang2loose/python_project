**BattleShips Client**

This is the BattleShips Client Gui and our first try of distributing it.

To start the client navigate your terminal to this folder and run `python setup.py install` then `cd BattleShipsClient` 
and run `python BattleShipsClient.py`